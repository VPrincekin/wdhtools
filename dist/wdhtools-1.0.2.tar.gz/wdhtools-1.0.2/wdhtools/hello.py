#!/usr/bin/env python
# coding: utf-8

# @Author: dehong
# @Date: 2020-06-04
# @Time: 17:17
# @Name: hello


def hello():
    return 'hello word'

b = hello()